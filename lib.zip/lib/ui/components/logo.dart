import 'package:flutter/material.dart';

Widget displayLogo() {
  return

      /*IntrinsicHeight(
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            height: 80,
          ),
*/

      Center(
    //child: Padding(
    //padding: EdgeInsets.only(top: 60),
    child: SizedBox(
      width: 100,
      child: Image.asset(
        'assets/img/logo.png',
        fit: BoxFit.fill,
        filterQuality: FilterQuality.high,
      ),
    ),
    //),
  );

/*
        ],
      ),
    ),
  );
  */
}
