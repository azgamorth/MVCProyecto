import 'package:flutter/material.dart';
import '../theme/theme.dart';

class CustomFieldWidget extends StatelessWidget {
  final TextEditingController fieldController;
  final double fontsize;
  final String hintText;
  final Widget? icon;
  final bool obscureText;
  final double paddind;

  const CustomFieldWidget(
      {Key? key,
      required this.fieldController,
      this.fontsize = 12,
      this.hintText = "",
      this.icon,
      this.obscureText = false,
      this.paddind = 40})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: EdgeInsets.fromLTRB(paddind, 0, paddind, 0),
        child: TextField(
          autocorrect: false,
          controller: fieldController,
          style: TextStyle(
              color: Color.fromARGB(255, 138, 135, 135),
              fontSize: fontsize,
              fontWeight: FontWeight.bold),
          obscureText: obscureText,
          decoration: InputDecoration(
              fillColor: Colors.white38,
              filled: true,
              hintText: hintText,
              // labelText: '',
              suffixIcon: icon, //Icon(Icons.alternate_email),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: FondoGrisColor, width: 2.0),
              ),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(color: FondoGrisColor, width: 2.0),
              ),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(60.0))),
          //onChanged: (value) {},
        ));
  }
}
