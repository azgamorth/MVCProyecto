import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ConfigIpProvider extends ChangeNotifier {
  List<dynamic> dataJson = [];

  ConfigIpProvider() {
    String data = "";
    try {
      rootBundle.loadString('assets/data/token.json').then((value) {
        data = value;
        dataJson = json.decode(data);
      });
    } catch (e) {
      print("Error $e ");
    }
  }

  Map getTokenCredentials(String key) {
    Map result = {};
    for (var element in dataJson) {
      if (element["name"] == key) {
        result = element;
      }
    }
    return result;
  }
}
