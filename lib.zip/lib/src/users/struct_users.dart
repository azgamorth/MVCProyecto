import 'dart:convert';

class StructUsers {
  String _email = "";
  String _password = "";
  String _picture = "";
  String _name = "";
  String _lastname = "";
  String _city = "";
  String _state = "";
  String _country = "";
  String _phone_number = "";
  String _resident_address = "";
  String _cod_club = "";

  StructUsers() {}

  StructUsers toJson(String strJson) {
    StructUsers users = new StructUsers();
    Map userJson = json.decode(strJson);
    users.setEmail(userJson['email']);
    users.setName(userJson['name']);
    users.setLastName(userJson['lastname']);
    users.setPicture(userJson['picture']);
    users.setCity(userJson['city']);
    users.setState(userJson['state']);
    users.setPhoneNumber(userJson['phone_number']);
    users.setResidentAddress(userJson['resident_address']);
    users.setCodClub(userJson['cod_club']);
    return users;
  }

  String getResidentAddress() => _resident_address;
  setResidentAddress(String residentAdress) {
    _resident_address = residentAdress;
  }

  String getCompleteName() {
    return '$_name $_lastname';
  }

  String getPhoneNumer() => _phone_number;
  setPhoneNumber(String phoneNumber) {
    _phone_number = phoneNumber;
  }

  String getCity() => _city;
  setCity(String city) {
    _city = city;
  }

  String getCodClub() => _cod_club;
  setCodClub(String club) {
    _cod_club = club;
  }

  String getState() => _state;
  setState(String state) {
    _state = state;
  }

  String getEmail() => _email;
  setEmail(String email) {
    _email = email;
  }

  String getPassword() => _password;
  setPassword(String password) {
    _password = password;
  }

  String getPicture() => _picture;
  setPicture(String picture) {
    _picture = picture;
  }

  String getName() => _name;
  setName(String name) {
    _name = name;
  }

  String getLastName() => _lastname;
  setLastName(String lastname) {
    _lastname = lastname;
  }
}
