import 'package:flutter/material.dart';
import '../../routes/routes.dart';

import '../../src/session/Session.dart';
import '../constants.dart';
import '../profile/profile_page.dart';
import '../settings/settings_page.dart';
import 'home_page.dart';
import 'widgets/widgets.dart';

//final PageController _controller = PageController();

class Home extends StatefulWidget {
  Home() {}

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int _selectedIndex = 0;

  PageController? _controller;
  List<Widget>? _pages;

  _HomeState() {}

  @override
  void initState() {
    super.initState();
    _controller = PageController(
      initialPage: _selectedIndex,
    );
    _pages = [
      HomePage(),
      ProfilePage(
        onScroll: (dragStartDetails) {
          return _controller!.position.drag(dragStartDetails, () {});
        },
      ),
      //MessagesPage(),
      SettingsPage(),
    ];
  }

  @override
  void dispose() {
    super.dispose();
    _controller!.dispose();
  }

  _selectPage(int index) {
    setState(() {
      if (_controller!.hasClients) _controller!.jumpToPage(index);
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 1,
        automaticallyImplyLeading: false,
        title: AppBarTitleWidget(),
        actions: <Widget>[
          _selectedIndex == 2
              ? IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.add,
                    color: kColorBlue,
                  ),
                )
              : IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.notifications_none,
                    color: kColorBlue,
                  ),
                ),
        ],
      ),
      body: PageView(
        controller: _controller,
        onPageChanged: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        children: _pages!,
      ),
      floatingActionButton: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Color(0x202e83f8),
        ),
        child: Padding(
          padding: EdgeInsets.all(15),
          child: GestureDetector(
            onTap: () {
              // Navigator.of(context).pushNamed(Routes.bookingStep1);
            },
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: kColorBlue,
              ),
              child: Icon(
                Icons.add,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        elevation: 0,
        child: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            Expanded(
              flex: 1,
              child: NavBarItemWidget(
                onTap: () {
                  _selectPage(0);
                },
                iconData: Icons.home,
                text: 'Inicio',
                color: _selectedIndex == 0 ? kColorBlue : Colors.grey,
              ),
            ),
            Expanded(
              flex: 1,
              child: NavBarItemWidget(
                onTap: () {
                  _selectPage(1);
                },
                iconData: Icons.person,
                text: 'Perfil',
                color: _selectedIndex == 1 ? kColorBlue : Colors.grey,
              ),
            ),
            Expanded(
              flex: 1,
              child: SizedBox(
                height: 1,
              ),
            ),
            Expanded(
              flex: 1,
              child: NavBarItemWidget(
                onTap: () {
                  _selectPage(2);
                },
                iconData: Icons.message,
                text: 'Mensajes',
                color: _selectedIndex == 2 ? kColorBlue : Colors.grey,
              ),
            ),
            Expanded(
              flex: 1,
              child: NavBarItemWidget(
                onTap: () {
                  _selectPage(3);
                },
                iconData: Icons.settings,
                text: 'Ajustes',
                color: _selectedIndex == 3 ? kColorBlue : Colors.grey,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
