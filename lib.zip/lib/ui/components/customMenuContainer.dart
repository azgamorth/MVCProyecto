import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../constants.dart';

class MenuContainer extends StatelessWidget {
  final String titulo1;
  final String titulo2;
  final Color backgroudColor;
  final Function onClick;

  const MenuContainer(
      {super.key,
      this.titulo1 = "",
      this.titulo2 = "",
      this.backgroudColor = kColorPink,
      required this.onClick});

  @override
  Widget build(BuildContext context) {
    return Container(
        width: double.infinity,
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4),
          color: backgroudColor,
        ),
        // child: Expanded(
        child: Column(
          children: [
            Text(
              titulo1,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w400,
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            Text(
              titulo2,
              style: kInputTextStyleAlter,
            ),
            const SizedBox(
              height: 15,
            ),
            CupertinoButton(
              color: Colors.white,
              borderRadius: BorderRadius.circular(4.0),
              child: Text(
                'Ir',
                style: TextStyle(color: backgroudColor),
              ),
              onPressed: (() {
                onClick();
              }),
            )
          ],
        ));
  }
}
