import 'package:flutter/material.dart';

import '../constants.dart';

class CustomTextFormField extends StatefulWidget {
  final TextEditingController controller;
  final String hintText;
  final bool obscureText;
  final bool enabled;
  final Widget suffixIcon;
  final bool suffixIconTap;
  final String error;
  final TextInputType keyboardType;
  final double fontsize;

  const CustomTextFormField({
    Key? key,
    required this.controller,
    this.hintText = "",
    this.keyboardType = TextInputType.text,
    this.obscureText = false,
    this.enabled = true,
    this.suffixIcon = const Icon(Icons.ac_unit_outlined),
    this.suffixIconTap = true,
    this.error = "",
    this.fontsize = 16,
    //List<WhitelistingTextInputFormatter> inputFormatters
  }) : super(key: key);

  @override
  _CustomTextFormFieldState createState() => _CustomTextFormFieldState();
}

class _CustomTextFormFieldState extends State<CustomTextFormField> {
  bool _obscureText = false;
  @override
  void initState() {
    _obscureText = widget.obscureText;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: ThemeData().copyWith(
        primaryColor: kColorBlue,
      ),
      child: TextFormField(
        keyboardType: widget.keyboardType,
        obscureText: _obscureText,
        controller: widget.controller,
        enabled: widget.enabled,
        decoration: InputDecoration(
          hintText: widget.hintText,
          hintStyle: TextStyle(
            fontSize: widget.fontsize,
            color: Color(0xffbcbcbc),
            fontFamily: 'NunitoSans',
          ),
          errorText: widget.error,
          suffixIcon: (widget.obscureText != null && widget.obscureText)
              ? GestureDetector(
                  onTap: () {
                    setState(() {
                      _obscureText = !_obscureText;
                    });
                  },
                  child: Container(
                    padding: EdgeInsets.all(10),
                    child: Icon(
                      _obscureText ? Icons.visibility : Icons.visibility_off,
                      size: 15,
                    ),
                  ),
                )
              : widget.suffixIcon,
        ),
        style: TextStyle(
          fontSize: widget.fontsize,
          color: Color(0xff575757),
          fontFamily: 'NunitoSans',
        ),
        cursorColor: kColorBlue,
        cursorWidth: 1,
      ),
    );
  }
}
