import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../src/session/Session.dart';

import '../constants.dart';

class HomePage extends StatefulWidget {
  HomePage() {}

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
    with AutomaticKeepAliveClientMixin<HomePage> {
  _HomePageState() {}

  final bool _noAppoints = false;
  Session sesion = new Session();

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return SingleChildScrollView(
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(" TOKEN ${sesion.gettoken()}"),
            Text(
              'Centro Médico San Miguel S.L.',
              style: TextStyle(
                color: kColorDarkBlue,
                fontSize: 21,
                fontFamily: 'NunitoSans',
                fontWeight: FontWeight.w400,
              ),
            ),
            Text(
              'Trovador Xoán García de Guillade, 33',
              style: TextStyle(
                color: Colors.blueGrey,
                fontSize: 16,
                fontWeight: FontWeight.w400,
              ),
            ),
            Text(
              '36860 Ponteareas',
              style: TextStyle(
                color: Colors.blueGrey,
                fontSize: 16,
                fontWeight: FontWeight.w400,
              ),
            ),
            Text(
              'Tel: 986 642212 Fax: 986 640516',
              style: TextStyle(
                color: Colors.blueGrey,
                fontSize: 16,
                fontWeight: FontWeight.w400,
              ),
            ),
            SizedBox(
              height: 25,
            ),
            SizedBox(
              width: double.infinity,
              child: CupertinoButton.filled(
                  child: Text('Quiero Solicitar una cita'),
                  onPressed: () {
                    //Navigator.of(context).pushNamed(Routes.psmbookingStep1);
                  }),
            ),
            SizedBox(
              height: 25,
            ),
            Text(
              'Para modificar o anular una cita reservada, por favor digite el código localizador que recibió en su buzón de correo electrónico',
              style: TextStyle(
                color: Colors.blueGrey,
                fontSize: 16,
                fontWeight: FontWeight.w400,
              ),
            ),
            SizedBox(
              height: 25,
            ),
            Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: kColorBlue,
              ),
              child: Expanded(
                child: Column(
                  children: [
                    Text(
                      'Quiero MODIFICAR una cita ya solicitada',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      'Localizador',
                      style: kInputTextStyleAlter,
                    ),
                    /*CustomTextFormField(
                         controller: _nameController,
                         hintText: _patient ? '' : 'Tawfiq Bahri',
                        ),
                        */
                    SizedBox(
                      height: 15,
                    ),
                    CupertinoButton(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(4.0),
                        child: Text(
                          'Modificar',
                          style: TextStyle(color: kColorBlue),
                        ),
                        onPressed: () {}),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 25,
            ),
            Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: kColorPink,
              ),
              child: Expanded(
                child: Column(
                  children: [
                    Text(
                      'Quiero ANULAR una cita ya solicitada',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      'Localizador',
                      style: kInputTextStyleAlter,
                    ),
                    /*
                    CustomTextFormField(
                        // controller: _nameController,
                        // hintText: _patient ? '' : 'Tawfiq Bahri',
                        ),
                        */
                    SizedBox(
                      height: 15,
                    ),
                    CupertinoButton(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(4.0),
                        child: Text(
                          'Modificar',
                          style: TextStyle(color: kColorPink),
                        ),
                        onPressed: () {}),
                  ],
                ),
              ),
            ),

            /*

             */
          ],
        ),
      ),
    );
  }

  @override
  bool get wantKeepAlive => true;
}
