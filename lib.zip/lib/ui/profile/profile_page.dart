import '../components/round_icon_button.dart';
import '../constants.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../home/home.dart';

class ProfilePage extends StatefulWidget {
  final Function onScroll;

  const ProfilePage({Key? key, required this.onScroll}) : super(key: key);
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage>
    with AutomaticKeepAliveClientMixin<ProfilePage> {
  final _kTabTextStyle = TextStyle(
    color: kColorBlue,
    fontSize: 12,
    fontWeight: FontWeight.w400,
    fontStyle: FontStyle.normal,
  );

  final _kTabPages = [
    /*
    VisitPage(),
    ExaminationPage(),
    TestPage(),
    PrescriptionPage(),
    */
    Home(),
  ];

  @override
  Widget build(BuildContext context) {
    super.build(context);
    // Local dragStartDetail.
    DragStartDetails? dragStartDetails;
    // Current drag instance - should be instantiated on overscroll and updated alongside.
    Drag drag;
    var _kTabs = [
      Tab(
        text: 'Visit',
      ),
      Tab(
        text: 'Examination',
      ),
      Tab(
        text: 'Test',
      ),
      Tab(
        text: 'Prescription',
      ),
    ];

    return Column(
      children: <Widget>[
        Container(
          padding: EdgeInsets.all(20),
          color: Colors.white,
          child: Row(
            children: <Widget>[
              CircleAvatar(
                radius: 32,
                backgroundColor: Colors.transparent,
                child: Image.asset(
                  'assets/images/icon_man.png',
                  fit: BoxFit.fill,
                ),
              ),
              SizedBox(
                width: 20,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Tawfiq Bahri',
                      style: TextStyle(
                        color: kColorDarkBlue,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(
                      height: 3,
                    ),
                    Text(
                      'bhr.tawfik@gmail.com',
                      style: TextStyle(
                        color: Colors.grey[350],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      '+213 781 348 677',
                      style: TextStyle(
                        color: kColorDarkBlue,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              RoundIconButton(
                onPressed: () {},
                icon: Icons.edit,
                size: 40,
                color: kColorBlue,
                iconColor: Colors.white,
              ),
            ],
          ),
        ),
        SizedBox(
          height: 15,
        ),
        Expanded(
          child: DefaultTabController(
            length: _kTabs.length,
            child: Column(
              children: <Widget>[
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Color(0xfffbfcff),
                    border: Border(
                      top: BorderSide(
                        width: 1,
                        color: Colors.grey[200]!,
                      ),
                      bottom: BorderSide(
                        width: 1,
                        color: Colors.grey[200]!,
                      ),
                    ),
                  ),
                  child: TabBar(
                    indicatorColor: kColorBlue,
                    labelStyle: _kTabTextStyle,
                    unselectedLabelStyle:
                        _kTabTextStyle.copyWith(color: Colors.grey),
                    labelColor: kColorBlue,
                    unselectedLabelColor: Colors.grey,
                    tabs: _kTabs,
                  ),
                ),
                Expanded(
                  child: NotificationListener(
                    onNotification: (notification) {
                      if (notification is ScrollStartNotification) {
                        dragStartDetails = notification.dragDetails!;
                      }
                      if (notification is OverscrollNotification) {
                        // drag = widget.pageController.position
                        //     .drag(dragStartDetails, () {});
                        drag = widget.onScroll(dragStartDetails);
                        drag.update(notification.dragDetails!);
                      }
                      if (notification is ScrollEndNotification) {
                        //drag.cancel();
                      }
                      return true;
                    },
                    child: TabBarView(
                      children: _kTabPages,
                    ),
                  ),
                ),
              ],
            ),
          ),
        )
      ],
    );
  }

  @override
  bool get wantKeepAlive => true;
}
