import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'package:multi_select_flutter/multi_select_flutter.dart';

import '../../providers/users/restApi.dart';
import '../../providers/users/user_db_provider.dart';
import '../../src/session/Session.dart';
import '../../utils/utils.dart';
import '../components/custom_button.dart';
import '../components/custom_field.dart';
import '../theme/theme.dart';

import '/../routes/routes.dart';
import 'package:flutter/material.dart';
import 'package:shaio_lib/shaio_lib.dart';

//0.11 Se agrega en el momento del QR un dialogo de confirmación
//0.12 Se agrega bandera cuando lea el código para que no haga varios pop
//0.13 Se añade la seccion en la tarjeta del paciente
//0.14 En los registros de revista es multilinea, y trae el último DX
//0.15 Para cualquier campo de ingreso de visita médica trae la información

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints viewportConstraints) {
          return SingleChildScrollView(
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: viewportConstraints.maxHeight,
              ),

              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 38),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const SizedBox(
                      height: 10,
                    ),
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.only(top: 60),
                        child: SizedBox(
                          width: 140,
                          child: Image.asset(
                            'assets/img/logo.png',
                            fit: BoxFit.fill,
                            filterQuality: FilterQuality.high,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    const WidgetSignin(),
                  ],
                ),
              ),
              // ),
            ),
          );
        },
      ),
    );
  }
}

class WidgetSignin extends StatefulWidget {
  const WidgetSignin({super.key});

  @override
  _WidgetSigninState createState() => _WidgetSigninState();
}

enum _SupportState {
  unknown,
  supported,
  unsupported,
}

class CTipoDocumento {
  final String id;
  final String nombre;

  CTipoDocumento({
    required this.id,
    required this.nombre,
  });
}

class _WidgetSigninState extends State<WidgetSignin> {
// Biometria
  final LocalAuthentication auth = LocalAuthentication();
  _SupportState _supportState = _SupportState.unknown;
  bool? _canCheckBiometrics;
  //List<BiometricType>? _availableBiometrics;
  bool isLoading = false;
  bool obscureText = true;

//

  final _documentController = TextEditingController();
  final _passwordController = TextEditingController();

  final List<String> items = [
    'Cédula',
    'Tarejeta de identidad',
    'Pasaporte',
  ];
  String? selectedValue;

  static List<CTipoDocumento> _tiposDocumento = <CTipoDocumento>[
    CTipoDocumento(id: 'C', nombre: 'Cédula'),
    CTipoDocumento(id: 'T', nombre: 'Tarejeta de identidad'),
    CTipoDocumento(id: 'P', nombre: 'Pasaporte'),
  ];

  final _lTiposDocumentos = _tiposDocumento
      .map((_tiposDocumento) => MultiSelectItem<CTipoDocumento>(
          _tiposDocumento, _tiposDocumento.nombre))
      .toList();

  String valorTipoDocumento = "";

  @override
  void initState() {
    super.initState();
    auth.isDeviceSupported().then(
          (bool isSupported) => setState(() => _supportState = isSupported
              ? _SupportState.supported
              : _SupportState.unsupported),
        );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        const Center(
            child: Text(
          "Pacientes",
          style: TextStyle(
              color: Colors.black,
              fontStyle: FontStyle.italic,
              fontSize: 48,
              fontWeight: FontWeight.bold),
        )),
        const SizedBox(
          height: 40,
        ),
        Padding(
            padding:
                const EdgeInsets.only(top: 9, bottom: 3, left: 39, right: 40),
            child: Container(
                decoration: BoxDecoration(
                    border: Border.all(
                  color: Colors.black54,
                  width: 2,
                )),
                child: DropdownButtonHideUnderline(
                    child: DropdownButton2<String>(
                        dropdownStyleData: const DropdownStyleData(
                          maxHeight: 200,
                        ),
                        iconStyleData: const IconStyleData(
                          openMenuIcon: Icon(Icons.arrow_drop_up),
                        ),
                        isExpanded: true,
                        hint: const Row(
                          children: [
                            Icon(
                              Icons.list,
                              size: 16,
                              color: Colors.black54,
                            ),
                            SizedBox(
                              width: 4,
                            ),
                            Expanded(
                              child: Text(
                                'Tipo de identificación',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black54,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                        items: items
                            .map((String item) => DropdownMenuItem<String>(
                                  value: item,
                                  child: Text(
                                    item,
                                    style: const TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black54,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ))
                            .toList(),
                        value: selectedValue,
                        onChanged: (String? value) {
                          setState(() {
                            selectedValue = value;
                          });
                        })))),
        //////
        const SizedBox(
          height: 20,
        ),
        _fieldNumeroDocumento(),
        const SizedBox(
          height: 20,
        ),
        _fieldPassword(),
        const SizedBox(
          height: 20,
        ),
        isLoading
            ? const Center(child: CircularProgressIndicator())
            : _btnLogin(context),
        const SizedBox(
          height: 20,
        ),
        Center(
          child: TextButton(
            onPressed: () {
              //Navigator.of(context)
              //   .pushNamed(Routes.forgotPassword);
            },
            child: const Text(
              'Términos y condiciones',
              style: TextStyle(
                color: ShaioTheme.secondary,
                fontSize: 12,
                fontFamily: shaiofontFamily,
              ),
            ),
          ),
        ),
        Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Tienes biometrico?',
                style: TextStyle(
                  color: Color(0xffbcbcbc),
                  fontSize: 12,
                  fontFamily: shaiofontFamily,
                ),
              ),
              InkWell(
                borderRadius: BorderRadius.circular(2),
                onTap: () {
                  _btnSignUpFaceId(context);
                },
                child: const Padding(
                  padding: EdgeInsets.all(5),
                  child: Text(
                    'Ingreso',
                    style: TextStyle(
                      color: ShaioTheme.secondary,
                      fontSize: 12,
                      fontFamily: shaiofontFamily, //'Poppins-Bold',
                    ),
                  ),
                ),
              ),
            ]),
        const SizedBox(
          height: 20,
        ),
        const Center(
            child: Text(
          "Version ",
          style: TextStyle(color: Colors.black38, fontSize: 8),
        )),
      ],
    );
  }

  _btnSignUpFaceId(BuildContext context) async {
    DBProvider db = DBProvider();
    List<Map> userInfoDB = await db.validarLogin();

    if (userInfoDB.isNotEmpty) {
      var usuario = userInfoDB[0]["usuario"];
      var clave = userInfoDB[0]["clave"];

      bool validateUserGetToken =
          await prePerformLogin(context, usuario, clave);
      if (!validateUserGetToken) {
        mostrar_alerta(context, 'ERROR', 'Las credenciales cambiaron');
        db.deleteLogin();
        return;
      }
/*
      if (!await _checkBiometrics()) {
        mostrar_alerta(context, 'ERROR', 'EL dispositivo no tiene biometricos');
        db.deleteLogin();
        return;
      }
      */
      // Security FAceID
      //Navigator.of(context).popAndPushNamed(Routes.home);
      if (!await _authenticate()) {
        mostrar_alerta(context, 'ERROR', 'Error en la valiadacion');
        db.deleteLogin();
        return;
      }

      Navigator.of(context).popAndPushNamed(Routes.home);
    } else {
      if (_documentController.text == '' && _passwordController.text == '') {
        mostrar_alerta(context, 'ERROR',
            'Deben ingresar usuario y contraseña para activar Id por hardware');
        return;
      }

      bool validateUserGetToken = await prePerformLogin(
          context, _documentController.text, _passwordController.text);
      if (!validateUserGetToken) return;

      db.insertLogin(
          usuario: _documentController.text, clave: _passwordController.text);
      Navigator.of(context).popAndPushNamed(Routes.home);
    }
  }

  Widget _btnLogin(BuildContext context) {
    return Padding(
        padding: const EdgeInsets.fromLTRB(40, 0, 40, 0),
        child: CustomButton(
          onPressed: () {
            _performLogin(context);
          },
          text: 'Entrar',
        ));
  }

  Widget _fieldNumeroDocumento() {
    return CustomFieldWidget(
      fieldController: _documentController,
      hintText: "Número de documento",
      fontsize: 18,
    );
  }

  Widget _fieldPassword() {
    return CustomFieldWidget(
      icon: IconButton(
          onPressed: () {
            setState(() {
              obscureText = !obscureText;
            });
          },
          icon: obscureText
              ? const Icon(
                  Icons.visibility,
                  color: ShaioTheme.primary,
                )
              : const Icon(Icons.visibility_off, color: ShaioTheme.secondary)),
      fieldController: _passwordController,
      hintText: "Clave",
      obscureText: obscureText,
      fontsize: 18,
    );
  }

  /// Llama el servicio del login para verificar que el usuario
  /// Efectivamente existe

  Future<bool> prePerformLogin(
      BuildContext context, String documento, String clave) async {
    setState(() {
      isLoading = true;
    });
    Map<String, dynamic> _resp_token = {};
    ServidorProvider ser = ServidorProvider(context);
    _resp_token = await ser.getToken(context, documento.toUpperCase(), clave);

    setState(() {
      isLoading = false;
    });
    if (_resp_token.isEmpty) {
      mostrar_alerta(context, 'INVALIDO', 'Usuario o clave incorrecta');
      return false;
    }
    if (_resp_token['errorCode'] != 0) {
      mostrar_alerta(context, 'INVALIDO', _resp_token['errorMessage']);
      return false;
    }

    isesion.setUsuario(documento);
    isesion.setClave(clave);
    isesion.settoken(_resp_token['data']['token']);

    return true;
  }

  _performLogin(BuildContext context) async {
    if (await prePerformLogin(
        context, _documentController.text, _passwordController.text)) {
      Navigator.of(context).popAndPushNamed(Routes.home);
    }
  }

  Future<bool> _authenticate() async {
    bool authenticated = false;
    try {
      authenticated = await auth.authenticate(
        localizedReason: 'Let OS determine authentication method',
        options: const AuthenticationOptions(
          stickyAuth: true,
        ),
      );
    } on PlatformException catch (e) {
      return false;
    }
    if (!mounted) {
      return false;
    }
    return authenticated;
  }

  Future<bool> _checkBiometrics() async {
    late bool canCheckBiometrics;
    try {
      canCheckBiometrics = await auth.canCheckBiometrics;
    } on PlatformException catch (e) {
      canCheckBiometrics = false;
      print(e);
    }
    if (!mounted) {
      return false;
    }
    return canCheckBiometrics;
  }
}
