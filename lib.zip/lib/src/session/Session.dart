import 'dart:convert';
import '../../utils/utils.dart';
import '../users/struct_users.dart';

class Session {
  static String token = "";
  static String usuario = "";
  static String clave = "";

  static String pushNotificationToken = "";
  static String mensaje = ""; // Ultimo mensaje obtenido
  static String code = ""; // ultimo codigo obtenido
  static String version = "20230904";

  static StructUsers userData = StructUsers();

  StructUsers getUSerData() => userData;
  setUserData(StructUsers u) {
    userData = u;
  }

  String getVersion() => version;

  /// Toma el STR de la respuesta del servidor
  /// y pasa la estructura del JSON de la clase
  void toJsonApil(String str) async {
    str = Utils().stringFilter(str);
    var jsonMap = await json.decode(str);
    var menssages = jsonMap['messages'];
    mensaje = menssages[0]['message'];
    code = menssages[0]['code'];
  }

  /// Toma el STR de la respuesta del servidor
  /// y pasa la estructura del JSON de la clase
  void toJson(String str) async {
    var jsonMap = await json.decode(str);
    token = jsonMap['TOKEN'];
    mensaje = jsonMap['MSG'];
  }

  String getPushNotificationToken() => pushNotificationToken;
  setPushNotificationToken(String push) {
    pushNotificationToken = push;
  }

  String getmensaje() => mensaje;
  String gettoken() => token;
  settoken(String tok) {
    token = tok;
  }

  String getUsuario() {
    return usuario;
  }

  String getClave() {
    return clave;
  }

  void setUsuario(String pusuario) {
    usuario = pusuario;
  }

  void setClave(String pclave) {
    clave = pclave;
  }
}

final Session isesion = Session();
