import 'package:flutter/material.dart';
import '../../constants.dart';

class SectionHeaderWidget extends StatelessWidget {
  final String title;
  final Function onPressed;

  const SectionHeaderWidget({
    Key? key,
    required this.title,
    required this.onPressed,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 20),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Text(
              title,
              style: TextStyle(
                color: kColorDarkBlue,
                fontSize: 20,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          SizedBox(
            width: 5,
          ),
          onPressed != null
              ? TextButton(
                  onPressed: () {
                    onPressed();
                  },
                  child: Text(
                    'See All',
                    style: TextStyle(
                      color: kColorDarkBlue,
                      fontSize: 12,
                    ),
                  ),
                )
              : Container(),
        ],
      ),
    );
  }
}
