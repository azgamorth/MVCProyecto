import 'package:flutter/material.dart';

class CustomButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final double elevation;
  final double borderRadius;
  final double fontSize;
  final Color fillColor;

  const CustomButton(
      {Key? key,
      this.text = "",
      required this.onPressed,
      this.elevation = 0,
      this.fontSize = 18,
      this.borderRadius = 10,
      this.fillColor = const Color.fromARGB(250, 237, 34, 36)})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RawMaterialButton(
      onPressed: onPressed,
      elevation: elevation,
      fillColor: fillColor,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(borderRadius),
          side: BorderSide(color: Colors.black45, width: 1)),
      child: Padding(
        padding:
            const EdgeInsets.only(top: 18, bottom: 18, left: 16, right: 16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              text,
              style: TextStyle(
                color: Colors.white,
                fontSize: fontSize,
                fontWeight: FontWeight.bold,
                fontFamily: 'NunitoSans',
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
