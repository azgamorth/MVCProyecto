import 'dart:io';

import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class DBProvider {
  static Database? _database = null;
  static final DBProvider db = DBProvider._();
  // ignore: non_constant_identifier_names
  static const String _db_name = 'bd_shaio.db';
  static const int _version = 1;

  /// VERSIONES

  /// Importante cada vez que halla un cambio en la bd aumentar la versión

  DBProvider();

// Constructor privado
  DBProvider._();

  Future<Database?> get database async {
    if (_database != null) return _database;

    _database = await initDB();

    return _database;
  }

  Future<Database> initDB() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    final path = join(documentsDirectory.path, _db_name);
    //print(path);

    //Crear una base de datos
    return await openDatabase(path, version: _version, onOpen: (db) {},
        onCreate: (Database db, int version) async {
      await db.execute(
          '''
          CREATE TABLE login(
            usuario VARCHAR(250) PRIMARY KEY
            ,clave VARCHAR(250)             
          );
          ''');
    });
  }

  /// Inserta el registro en el login
  /// con el indicador validado
  Future<int> insertLogin(
      {required String usuario, required String clave}) async {
    final db = await database;
    final sql =
        '''
    INSERT INTO login(usuario,clave) VALUES('$usuario','$clave');
    ''';
    final res = await db!.rawInsert(sql);
    return res;
  }

  Future<int> deleteLogin() async {
    final db = await database;
    final sql = '''
    DELETE FROM login;
    ''';
    final res = await db!.rawDelete(sql);
    return res;
  }

  ///select seq from sqlite_sequence where name='ordenes'
  Future<List<Map>> validarLogin() async {
    final db = await database;
    List<Map> res = await db!.query('login');

/*
    var salida = '0';
    for (var row in res) {
      salida = row['validado'];
    }
    */
    return res;
  }
}
