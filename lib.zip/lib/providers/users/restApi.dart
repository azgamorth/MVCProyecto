import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import '../../utils/utils.dart';
import 'ConfigIpProvider.dart';

class ServidorProvider {
  static final ServidorProvider ser = ServidorProvider._();
  ServidorProvider._();

  String _url = ''; //'172.20.10.37:8080';
  String _servicio = '/shaio';

  ServidorProvider(BuildContext context) {
    final configGen = Provider.of<ConfigIpProvider>(context, listen: false);
    var config = configGen.getTokenCredentials("auth");
    _url = config["server"];
    _servicio = config["service"];
  }

  /// Valida usuario y contraseña y retorna el Token
  /// https://stackoverflow.com/questions/54285172/how-to-solve-flutter-certificate-verify-failed-error-while-performing-a-post-req
  Future<Map<String, dynamic>> getToken(
      BuildContext context, String usuario, String clave) async {
    if (usuario == '' || clave == '') return {};

    Map<String, dynamic> salida = {};
    final auth = 'Basic ${base64Encode(utf8.encode('$usuario:$clave'))}';

    var headers = {'Authorization': auth, 'Content-Type': 'application/json'};
    var params = {"application": "vesalius", "menu": "MENPRI"};
    var dio = Dio();
    Response response = await dio.post('http://$_url$_servicio/user/login',
        options: Options(headers: headers), data: params);

    debugPrint("$_url$_servicio");

    if (response.statusCode == 200) {
      salida = await response.data;
    } else {
      mostrar_alerta(
          context, "Error", "Error en conexión ${response.statusCode}");
    }
    return salida;
  }

  Future<String> validateUser(
      String token, String usuario, String clave) async {
    var salida = "";

    var headers = {
      'Authorization': 'Bearer $token',
      'Content-Type': 'application/json'
    };

    return salida;
  }
}
