import 'dart:async';

import 'package:flutter/material.dart';

import '../../routes/routes.dart';
import '../components/logo.dart';
import '../theme/theme.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  _SplashPageState createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    // DBProvider.db.initDB(); // Inicializa DB
    Timer(const Duration(seconds: 3), () => {_loadScreen()});
  }

  _loadScreen() async {
    //SharedPreferences prefs = await SharedPreferences.getInstance();
    // Navigator.of(context).popAndPushNamed(Routes.requestPin);
    Navigator.of(context).popAndPushNamed(Routes.login);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        color: FondoGrisColor,
        child: Column(
          children: <Widget>[
            Expanded(
              flex: 3,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Container(
                        decoration: const BoxDecoration(),
                        child: displayLogo(),
                      )

                      //),
                    ],
                  ),
                  Padding(
                      padding: const EdgeInsets.only(top: 28.0),
                      child: Column(children: [
                        const Text('Shaio Pacientes ',
                            style: TextStyle(
                                fontSize: 40, fontWeight: FontWeight.bold))
                      ]))
                  //),
                ],
              ),
            ),
            SizedBox(
              width: 150,
              height: 2,
              child: LinearProgressIndicator(
                backgroundColor: FondoGrisColor,
                valueColor: const AlwaysStoppedAnimation<Color>(Colors.black45),
              ),
            ),
            Expanded(
              flex: 1,
              child: Container(),
            )
          ],
        ),
      ),
    );
  }
}
