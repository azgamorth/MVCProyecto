import 'package:flutter/material.dart';

class CustomDropDownWidget extends StatelessWidget {
  final Widget widg;
  final VoidCallback onPressed;
  final double elevation;
  final double borderRadius;
  final List<String> lvalues;
  final String value = "";

  const CustomDropDownWidget(
      {Key? key,
      required this.widg,
      required this.onPressed,
      this.elevation = 0,
      this.borderRadius = 10,
      required this.lvalues})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 9, bottom: 10, left: 16, right: 16),
      child: DropdownMenu<String>(
        initialSelection: lvalues.first,
        onSelected: (String? value) {
          /*  setState(() {
              dropdownValue = value!;
          });*/
        },
        dropdownMenuEntries:
            lvalues.map<DropdownMenuEntry<String>>((String value) {
          return DropdownMenuEntry<String>(value: value, label: value);
        }).toList(),
      ),
    );
  }
}
