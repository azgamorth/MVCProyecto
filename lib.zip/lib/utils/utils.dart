import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'dart:core';

class Utils {
  String stringFilter(String str) {
    return str
        .replaceAll(" ", "")
        .replaceAll("\n", "")
        .replaceAll("\r", " ")
        .trim();
  }
}

/// Lee las credenciales del archivo JSON
Future<Map> getTokenCredentials(String key) async {
  String data = "";
  Map result = {};
  try {
    data = await rootBundle.loadString('assets/data/token.json');
    List<dynamic> dataJson = json.decode(data);

    for (var element in dataJson) {
      if (element["name"] == key) {
        result = element;
      }
    }
  } catch (e) {
    print("Error $e ");
  }
  return result;
}

show_dialog_working(BuildContext context) {
  return showDialog(
    context: context,
    barrierDismissible: true,
    builder: (context) {
      return Dialog(
        child: Card(
            child: Row(children: const [
          CircularProgressIndicator(
            semanticsLabel: 'Procesando',
          ),
          Text("    Espere por favor ..."),
        ])),
      );
    },
  );
  //new Future.delayed(new Duration(seconds: 3), () {});
}

// ignore: non_constant_identifier_names
void mostrar_alerta(BuildContext context, String titulo, String mensaje) {
  showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) {
        return SingleChildScrollView(
            child: AlertDialog(
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                textStyle: Theme.of(context).textTheme.labelLarge,
              ),
              child: const Text('Entendido'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
          //title: Text(titulo),
          shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(6.0))),
          content: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
            Row(mainAxisAlignment: MainAxisAlignment.start, children: [
              const Icon(
                Icons.block_outlined,
                color: Colors.red,
                size: 40.0,
              ),
              Text(
                ' $titulo!',
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 18.0),
              ),
            ]),
            const Divider(),
            Text(mensaje),
          ]),
        ));
      });
}

// ignore: non_constant_identifier_names
void mostrar_info(BuildContext context, String titulo, String mensaje) {
  showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) {
        return AlertDialog(
          //title: Text(titulo),

          actions: [
            TextButton(
              style: TextButton.styleFrom(
                textStyle: Theme.of(context).textTheme.labelLarge,
              ),
              child: const Text('Entendido'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
          shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(6.0))),
          content: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
            Row(mainAxisAlignment: MainAxisAlignment.start, children: [
              const Icon(
                Icons.info_outline,
                color: Colors.blue,
                size: 40.0,
              ),
              Text(
                ' $titulo!',
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 18.0),
              ),
            ]),
            const Divider(),
            Text(mensaje),
          ]),
        );
      });
}
