import 'package:flutter/material.dart';

class CustomField2 extends StatelessWidget {
  final String hintText;
  final TextEditingController controller;

  const CustomField2({
    Key? key,
    this.hintText = "",
    required this.controller,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(5, 0, 0, 0),
      child: TextField(
          keyboardType: TextInputType.multiline,
          minLines: 1, //Normal textInputField will be displayed
          maxLines: 5,
          controller: controller,
          style: const TextStyle(fontSize: 14),
          decoration: InputDecoration(
              fillColor: Colors.white38,
              filled: true,
              border: const OutlineInputBorder(),
              hintText: hintText,
              labelText: hintText)),
    );
  }
}
