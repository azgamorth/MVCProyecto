class Routes {
  static const String splash = '/';
  static const String login = '/login';
  static const String home = '/home';
  static const String revistaHome = '/revistaHome';
  static const String revistaInsertar = '/revistaInsertar';
}
