import 'package:flutter/cupertino.dart';
import '../ui/home/home_page.dart';
import '../ui/login/login_page.dart';
import '../ui/splash/splash.dart';
import 'routes.dart';

class RouteGenerator {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    //final args = settings.arguments;

    switch (settings.name) {
      case Routes.splash:
        return CupertinoPageRoute(builder: (_) => SplashPage());
      case Routes.login:
        return CupertinoPageRoute(builder: (_) => LoginPage());
      case Routes.home:
        return CupertinoPageRoute(builder: (_) => HomePage());
    }
    return CupertinoPageRoute(builder: (_) => SplashPage());
  }
}
