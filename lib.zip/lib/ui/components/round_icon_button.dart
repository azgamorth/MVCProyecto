import 'package:flutter/material.dart';

class RoundIconButton extends StatelessWidget {
  final IconData icon;
  final double size;
  final Color color;
  final Color iconColor;
  final double elevation;
  final VoidCallback onPressed;

  RoundIconButton(
      {super.key,
      required this.icon,
      this.size = 12,
      this.color = Colors.white12,
      this.iconColor = Colors.black87,
      this.elevation = 0,
      required this.onPressed});
  @override
  Widget build(BuildContext context) {
    return RawMaterialButton(
      onPressed: onPressed,
      shape: CircleBorder(),
      elevation: elevation,
      fillColor: color,
      constraints: BoxConstraints.tightFor(
        width: size,
        height: size,
      ),
      child: Icon(
        icon,
        color: iconColor,
      ),
    );
  }
}
