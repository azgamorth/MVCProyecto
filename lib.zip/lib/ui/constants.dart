import 'package:flutter/material.dart';

const kColorBlue = Color(0xff2e83f8);
const kColorDarkBlue = Color(0xff1b3a5e);
const kColorPink = Color(0xffff748d);

const kInputTextStyle = TextStyle(
    fontSize: 14,
    color: Color(0xffbcbcbc),
    fontWeight: FontWeight.w300,
    fontFamily: 'NunitoSans');

const kInputTextStyleAlter = TextStyle(
    fontSize: 14,
    color: Colors.white,
    fontWeight: FontWeight.w300,
    fontFamily: 'NunitoSans');

const String version = "20230810";
